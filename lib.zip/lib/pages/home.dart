
import 'package:flutter/material.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(110, 190, 0, 0),
          child: SafeArea(
            child: Column(
              children: <Widget>[
                SizedBox(
                  height: 65,
                  width: 170,
                  child: FlatButton(
                      onPressed:() {
                        Navigator.pushNamed(context, '/newnote');
                        },
                      child: Text(
                        'Create Note',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                        ),
                      ),
                    color: Colors.grey[800],
                    shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(50.0)),
                  ),
                ),
                SizedBox(height: 20,),

                SizedBox(

                  height: 65,
                  width: 170,

                  child: FlatButton(
                    onPressed:() {
                      Navigator.pushNamed(context, '/notes');
                      },
                    child: Text(
                      'Edit Note',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                    color: Colors.grey[800],
                      shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(50.0))
                  ),
                ),
                SizedBox(height: 20,),

                SizedBox(

                  height: 65,
                  width: 170,

                  child: FlatButton(
                    onPressed:() {
                      Navigator.pushNamed(context, '/notes');
                      },
                    child: Text(
                      'Delete Note',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                      ),
                    ),
                    color: Colors.grey[800],
                      shape: new RoundedRectangleBorder(borderRadius: new BorderRadius.circular(50.0))
                  ),
                ),
              ],
            ),
          ),
        ),
      ),

    );
  }
}
