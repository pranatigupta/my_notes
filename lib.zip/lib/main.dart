
import 'package:flutter/material.dart';
import 'package:my_notes/pages/home.dart';
import 'package:my_notes/pages/loading.dart';
import 'package:my_notes/pages/newnote.dart';
import 'package:my_notes/pages/notes.dart';

void main() {
  runApp(MaterialApp(
    initialRoute: '/home',
    routes:{
      '/' : (context) => Loading(),
      '/home' : (context) => Home(),
      '/newnote' : (context) => NewNote(),
      '/notes' : (context) => Notes(),
}

));
}
