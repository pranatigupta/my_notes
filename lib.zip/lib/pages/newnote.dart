import 'dart:io';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:my_notes/pages/notes.dart';
import 'package:path_provider/path_provider.dart';

class NewNote extends StatefulWidget {

  NewNote({Key key, @required this.title}) : super(key: key);
  final String title;

  @override
  _NewNoteState createState() => _NewNoteState();
}

class _NewNoteState extends State<NewNote> {

   final title = TextEditingController();
  final description = TextEditingController();

  void _sendData(BuildContext context) {
    Navigator.push(
      context,
        MaterialPageRoute(
          builder: (context) =>
             Notes(
                data: fileContent.toString(),
              ),
        ));
  }


   File jsonFile;
   Directory dir;
   String filename = "mynotes.json";
   bool fileExists = false;
   Map<String,String> fileContent;

  @override
  void initState() {
    super.initState();
    getApplicationDocumentsDirectory().then((Directory directory) {
      dir = directory;
      jsonFile =  new File(dir.path + "/" + filename);
      fileExists = jsonFile.existsSync();
      if(fileExists) this.setState(() => fileContent = json.decode(jsonFile.readAsStringSync()));
    });
  }


  @override
  void dispose() {
    title.dispose();
    description.dispose();
    super.dispose();
  }


   File createFile(Map<String,String> content, Directory dir,String fileName) {
    print("creating file!");
    File file = new File(dir.path + "/" + filename);
    file.createSync();
    fileExists= true;
    file.writeAsStringSync(json.encode(content));

   }

   void writeToFile(String title, String description) {
    print("writing to file!");
    Map< String, String > content = {title : description};
    if(fileExists) {
      print("file Exists");
      Map<String,String> jsonFileContent = json.decode(jsonFile.readAsStringSync());
      jsonFileContent.addAll(content);
      jsonFile.writeAsStringSync(json.encode(jsonFileContent));
    } else{
      print("file does not exists");
      createFile(content,dir,filename);
    }
      this.setState(() => fileContent= JSON.decode(jsonFile.readAsStringSync()));
   }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'NEW NOTE',
          style: TextStyle(
            color: Colors.grey[100],

          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.grey[800],
      ),

      body: Center(
        child: Container(
          margin: const EdgeInsets.all(10.0),
          width: 300.0,
          height: 400.0,
          padding: EdgeInsets.fromLTRB(18, 25, 18, 0),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(35)),
            color: Colors.grey[400],
          ),
          child: Column(
            children: <Widget>[
              TextField(
                decoration: InputDecoration(
                    hintText: 'Title'
                ),
                controller: title,
              ),
              SizedBox(height: 20,),
              TextField(
                keyboardType: TextInputType.multiline,
                maxLines: null,
                decoration: InputDecoration(hintText: 'Description'),
                controller: description,

              ),
              SizedBox(height: 175,),
              SizedBox(
                height: 55,
                width: 140,

                child: FlatButton(
                    onPressed: () {
                      // _sendData(context);
                       writeToFile(title.text, description.text);
                    },

                    child: Text(
                      'Done',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 20,
                        letterSpacing: 1,
                      ),
                    ),
                    color: Colors.grey[600],
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(50.0))
                ),
              ),
              Text(
                  fileContent.toString()
              ),
            ],
          ),
        ),
      ),
    );
  }
}

