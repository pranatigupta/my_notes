import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';


class Notes extends StatelessWidget {
  final  data;

  // receive data from the FirstScreen as a parameter
  Notes({
    Key key, @required this.data,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'MY NOTES',
          style: TextStyle(
            color: Colors.grey[100],

          ),
        ),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.grey[800],
      ),
      backgroundColor: Colors.grey[300],
      body: SafeArea(
        child: Column(
          children: <Widget>[
            Card(
              margin: EdgeInsets.fromLTRB(20, 20, 20, 0),
              child: Container(
                padding: EdgeInsets.fromLTRB(15.0, 15, 15, 0),
                child: Column(
                  children: <Widget>[
                       Text(
                        data,
                        style: TextStyle(
                        fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                    SizedBox(height: 15,),
                     Text(
                        data,
                       style: TextStyle(
                         color: Colors.grey[700],
                         fontSize: 15,
                       ),
                      ),
                    SizedBox(height: 15,),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: <Widget>[
                        FlatButton(
                          child: const Text('EDIT'),
                          onPressed: () {/* ... */},
                        ),

                        FlatButton(
                           child: const Text('DELETE'),
                            onPressed: () {/* ... */},
                        ),
                      ],
                    ),
                  ],
               ),
              )
            )
          ],
        ),
      ),
    );
  }
}